export default function EditarPerfil(props) {

  return (
    <div className="overlay">
     <div className="modal"> 
      <h2>Completa Perfgil</h2>
      <p>1 de 2</p>
     </div>
  )