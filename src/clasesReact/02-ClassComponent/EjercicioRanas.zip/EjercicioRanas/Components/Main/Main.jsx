import { Component } from "react";

export default class Main extends Component {

    render() {
        return (
            <section className="main-section">
                <h2>Bienvenido a nuestro ranario</h2>
                <p>En este lugar encontraras toda la información relativa a las ranas flecha.</p>
            </section>
        );
    }
}
